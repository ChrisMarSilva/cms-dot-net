﻿using Microsoft.Data.SqlClient;
using System;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GeradorModelo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        public MainWindow()
        {
            InitializeComponent();
            gerarModeloButton.Click += GerarModeloButton_Click;
            sanitizarSQLButton.Click += SanitizarSQLButton_Click;
            Closed += MainWindow_Closed;
            Loaded += MainWindow_Loaded;
        }

        private void SanitizarSQLButton_Click(object sender, RoutedEventArgs e)
        {
            string sql = codigoSqlTextBox.Text;

            sql = sql.Replace("''", "$")
                .Replace("'", "")
                .Replace("$", "'")
                .Replace("+", "")
                .Replace(";", "");

            var quoteFunction = Regex.Matches(sql, "quotedstr\\(.+\\)|IntToStr\\(.+\\)", RegexOptions.IgnoreCase);
            if (quoteFunction.Count > 0)
            {
                foreach (Match match in quoteFunction)
                {
                    var func = match.ToString();
                    var i = func.IndexOf('(') + 1;
                    var f = func.LastIndexOf(')');
                    var rep = $"'{func.Substring(i, f - i)}'";
                    sql = sql.Replace(func, rep);
                }
            }
            codigoSqlSanitizadoTextBox.Text = sql;
            Clipboard.SetText(sql);
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!File.Exists("config.json")) return;
                var buffer = File.ReadAllBytes("config.json");
                var config = JsonSerializer.Deserialize<Setting>(new ReadOnlySpan<byte>(buffer), new JsonSerializerOptions());

                LinhasEmBrancoCheckBox.IsChecked = config.LinhasEmBranco;
                OrdernarMembros.IsChecked = config.OrdernarMembros;

                NamespaceTextBox.Text = config.Namespace;
                NomeClasseTextBox.Text = config.NomeClasse;
                prefixoTextBox.Text = config.Prefixo;
                ConnectionStringTextBox.Text = config.StringConexao;
                sufixoTextBox.Text = config.Sufixo;
                codigoSqlTextBox.Text = config.CodigoSQL;
            }
            catch
            {
            }
        }

        private void MainWindow_Closed(object sender, EventArgs e)
        {
            try
            {
                using var sw = new StreamWriter("config.json", false);
                using var json = new System.Text.Json.Utf8JsonWriter(sw.BaseStream, new System.Text.Json.JsonWriterOptions()
                {
                    Indented = true
                });


                json.WriteStartObject();
                json.WriteBoolean("LinhasEmBranco", LinhasEmBrancoCheckBox.IsChecked ?? false);
                json.WriteBoolean("OrdernarMembros", OrdernarMembros.IsChecked ?? false);
                json.WriteString("Namespace", NamespaceTextBox.Text);
                json.WriteString("NomeClasse", NomeClasseTextBox.Text);
                json.WriteString("Prefixo", prefixoTextBox.Text);
                json.WriteString("StringConexao", ConnectionStringTextBox.Text);
                json.WriteString("Sufixo", sufixoTextBox.Text);
                json.WriteString("CodigoSQL", codigoSqlTextBox.Text);
                json.WriteEndObject();
                json.Flush();
            }
            catch
            {
            }
        }

        private void GerarModeloButton_Click(object sender, RoutedEventArgs e)
        {
            GerarModelo();
        }

        private void GerarModelo()
        {
            using var sqlConnection = new SqlConnection(ConnectionStringTextBox.Text);
            using var sqlCommand = new SqlCommand(codigoSqlSanitizadoTextBox.Text, sqlConnection);
            try
            {
                sqlConnection.Open();
                using var sqlDataReader = sqlCommand.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                var schema = sqlDataReader.GetColumnSchema();
                sqlDataReader.Close();
                sqlConnection.Close();

                var codigo = MontarCodigo(schema);
                entityConfigurationTextBox.Text = MontarCodigoEntiyConfiguration(schema);
                dtoTextBox.Text = MontarCodigoDto(schema);
                codigoCsharpTextBox.Text = codigo;
            }
            catch (Exception ex)
            {
                //Loga, etc...
                MessageBox.Show($"Ocorreu um erro ao gerar modelo.\r\n\r\n{ex.Message}\r\n{ex.StackTrace}", 
                    "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string MontarCodigoEntiyConfiguration(ReadOnlyCollection<DbColumn> schema)
        {
            StringBuilder sb = new StringBuilder();
            using var sw = new StringWriter(sb);
            using var provider = System.CodeDom.Compiler.CodeDomProvider.CreateProvider("csharp");
            CodeCompileUnit unit = new CodeCompileUnit();
            CodeNamespace ns = null;

            //Namespace
            ns = new CodeNamespace(NamespaceTextBox.Text);

            //Import                    
            ns.Imports.Add(new CodeNamespaceImport("System"));
            ns.Imports.Add(new CodeNamespaceImport("System.Collections.Generic"));
            ns.Imports.Add(new CodeNamespaceImport("System.ComponentModel"));
            ns.Imports.Add(new CodeNamespaceImport("Microsoft.EntityFrameworkCore"));
            ns.Imports.Add(new CodeNamespaceImport("Microsoft.EntityFrameworkCore.Metadata.Builders"));

            //Classe                                       
            var nomeClasse = $"{prefixoTextBox.Text}{NomeClasseTextBox.Text}{sufixoTextBox.Text}";
            CodeTypeDeclaration theClass = new CodeTypeDeclaration($"{nomeClasse}Configuration")
                {
                    Attributes = MemberAttributes.Public,
                    IsPartial = true,
                    IsClass = true
                };

            theClass.BaseTypes.Add($"IEntityTypeConfiguration<{nomeClasse}>");
            CodeMemberMethod cmm = new CodeMemberMethod()
            {
                Attributes = MemberAttributes.Public,
                Name = "Configure",
                ReturnType =  new CodeTypeReference(),
                Parameters = { new CodeParameterDeclarationExpression($"EntityTypeBuilder<{nomeClasse}>", $"builder") },
                Statements =
                {
                    new CodeMethodInvokeExpression(new CodeTypeReferenceExpression("builder"), "HasKey",
                        new CodePrimitiveExpression("Id"))

                }
            };
            
            CodeConstructor codeConstructor = new CodeConstructor();
            codeConstructor.Attributes = MemberAttributes.Public;
            theClass.Members.Add(codeConstructor);
            theClass.Members.Add(cmm);


            //Começa montar as propriedades
            CodeStatement cs = new CodeStatement()
            {
               UserData = {  }
            };
            
            
            ns.Types.Add(theClass);
            unit.Namespaces.Add(ns);

            var options = new CodeGeneratorOptions();
            options.BlankLinesBetweenMembers = LinhasEmBrancoCheckBox.IsChecked ?? false;
            options.BracingStyle = "C";
            options.VerbatimOrder = OrdernarMembros.IsChecked ?? false;
            provider.GenerateCodeFromCompileUnit(unit, sw, options);
            return sb.ToString();
        }

        private string MontarCodigo(ReadOnlyCollection<DbColumn> schema)
        {
            StringBuilder sb = new StringBuilder();
            using var sw = new StringWriter(sb);
            using var provider = System.CodeDom.Compiler.CodeDomProvider.CreateProvider("csharp");
            CodeCompileUnit unit = new CodeCompileUnit();
            CodeNamespace ns = null;

            //Namespace
            ns = new CodeNamespace(NamespaceTextBox.Text);

            //Import                    
            ns.Imports.Add(new CodeNamespaceImport("System"));
            ns.Imports.Add(new CodeNamespaceImport("System.Collections.Generic"));
            ns.Imports.Add(new CodeNamespaceImport("System.ComponentModel"));


            //Classe                                       
            CodeTypeDeclaration theClass = new CodeTypeDeclaration($"{prefixoTextBox.Text}{NomeClasseTextBox.Text}{sufixoTextBox.Text}");
            theClass.Attributes = MemberAttributes.Public;
            theClass.IsPartial = true;
            theClass.IsClass = true;

            CodeConstructor codeConstructor = new CodeConstructor();
            codeConstructor.Attributes = MemberAttributes.Public;
            codeConstructor.Statements.Add(new CodeCommentStatement("Adicione aqui a inicialização das collections"));
            theClass.Members.Add(codeConstructor);


            //Começa montar as propriedades

            foreach (var item in schema)
            {
                CodeTypeReference theType;
                bool isNullable = (item.AllowDBNull ?? false) && item.DataType.Name.ToLowerInvariant() != "string";
                if (isNullable && item.DataType.Name.ToLowerInvariant() != "byte[]") //Temos um tipo nullable
                {
                    theType = new CodeTypeReference($"Nullable<{item.DataType}>");
                }
                else
                {
                    theType = new CodeTypeReference(item.DataType);
                }

                CodeMemberField field = new CodeMemberField(theType, item.ColumnName);
                CodeMemberProperty member = new CodeMemberProperty();
                member.Name = ToPascalCase(item.ColumnName);
                member.Type = theType;
                member.Attributes = MemberAttributes.Public;
                member.HasGet = true;
                member.HasSet = true;
                var fieldName= $"_{ToPascalCase(item.ColumnName)}";
                field.Name = fieldName;
                field.Type = theType;

                
                member.GetStatements.Add(new CodeMethodReturnStatement(new CodeFieldReferenceExpression(new CodeThisReferenceExpression(), fieldName)));
                member.SetStatements.Add(new CodeAssignStatement(new CodeFieldReferenceExpression(new CodeThisReferenceExpression(), fieldName), new CodePropertySetValueReferenceExpression()));


                theClass.Members.Add(field);
                theClass.Members.Add(member);
            }
            //ProcessarTipos(type, theClass, false, string.Empty);

            ns.Types.Add(theClass);
            unit.Namespaces.Add(ns);

            var options = new CodeGeneratorOptions();
            options.BlankLinesBetweenMembers = LinhasEmBrancoCheckBox.IsChecked ?? false;
            options.BracingStyle = "C";
            options.VerbatimOrder = OrdernarMembros.IsChecked ?? false;
            provider.GenerateCodeFromCompileUnit(unit, sw, options);
            return sb.ToString();
        }

        private string MontarCodigoDto(ReadOnlyCollection<DbColumn> schema)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"public record {NomeClasseTextBox.Text} (");

            
            //Começa montar as propriedades

            foreach (var item in schema)
            {
                var sbAnnotation = new StringBuilder();
                CodeTypeReference theType;
                bool isNullable = (item.AllowDBNull ?? false) && item.DataType.Name.ToLowerInvariant() != "string";
                if (isNullable && item.DataType.Name.ToLowerInvariant() != "byte[]") //Temos um tipo nullable
                {
                    sb.Append($"{item.DataType.Name}? {ToPascalCase(item.ColumnName)},");
                }
                else
                {
                    if (item.DataType.Name.ToLowerInvariant().Contains("string"))
                    {
                        sbAnnotation.Append($"[MaxLength({item.ColumnSize})]");
                    }
                    
                    sb.Append($"{sbAnnotation.ToString()}{item.DataType.Name} {ToPascalCase(item.ColumnName)},");
                }
            }
            sb.Append(");");
            return sb.ToString();
        }

        static string CamelCase(string s)
        {
            var x = s.Replace("_", "");
            if (x.Length == 0) return "null";
            x = Regex.Replace(x, "([A-Z])([A-Z]+)($|[A-Z])",
                m => m.Groups[1].Value + m.Groups[2].Value.ToLower() + m.Groups[3].Value);
            return char.ToLower(x[0]) + x.Substring(1);
        }

        public string ToPascalCase(string original)
        {
            Regex invalidCharsRgx = new Regex("[^_a-zA-Z0-9]");
            Regex whiteSpace = new Regex(@"(?<=\s)");
            Regex startsWithLowerCaseChar = new Regex("^[a-z]");
            Regex firstCharFollowedByUpperCasesOnly = new Regex("(?<=[A-Z])[A-Z0-9]+$");
            Regex lowerCaseNextToNumber = new Regex("(?<=[0-9])[a-z]");
            Regex upperCaseInside = new Regex("(?<=[A-Z])[A-Z]+?((?=[A-Z][a-z])|(?=[0-9]))");

            // replace white spaces with undescore, then replace all invalid chars with empty string
            var pascalCase = invalidCharsRgx.Replace(whiteSpace.Replace(original, "_"), string.Empty)
                // split by underscores
                .Split(new char[] { '_' }, StringSplitOptions.RemoveEmptyEntries)
                // set first letter to uppercase
                .Select(w => startsWithLowerCaseChar.Replace(w, m => m.Value.ToUpper()))
                // replace second and all following upper case letters to lower if there is no next lower (ABC -> Abc)
                .Select(w => firstCharFollowedByUpperCasesOnly.Replace(w, m => m.Value.ToLower()))
                // set upper case the first lower case following a number (Ab9cd -> Ab9Cd)
                .Select(w => lowerCaseNextToNumber.Replace(w, m => m.Value.ToUpper()))
                // lower second and next upper case letters except the last if it follows by any lower (ABcDEf -> AbcDef)
                .Select(w => upperCaseInside.Replace(w, m => m.Value.ToLower()));

            return string.Concat(pascalCase);
        }
    }
    
    
}
