﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeradorModelo
{
    public class Setting
    {
        public string StringConexao { get; set; }
        public string Namespace { get; set; }
        public string Prefixo { get; set; }
        public string Sufixo { get; set; }
        public string CodigoSQL { get; set; }
        public string NomeClasse { get; set; }
        public bool LinhasEmBranco { get; set; }
        public bool OrdernarMembros { get; set; }
    }
}
